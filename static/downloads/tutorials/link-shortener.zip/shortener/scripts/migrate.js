/**
 * One-off schema migration — run before starting the bundle.
 *
 * Reads the same setup.sql the entity ships, so the schema has a single source
 * of truth. Safe to re-run: the statement is CREATE TABLE IF NOT EXISTS.
 *
 * Usage:
 *   node scripts/migrate.js                  # default database location
 *   node scripts/migrate.js /path/to/db.sqlite
 */
var fs           = require('fs');
var os           = require('os');
var path         = require('path');
var DatabaseSync = require('node:sqlite').DatabaseSync;

// Matches the connector's default: <gina home>/<database>.sqlite
var DEFAULT_DB = path.join(os.homedir(), '.gina', 'shortener.sqlite');
var SCHEMA     = path.join(__dirname, '..', 'src', 'api', 'models', 'shortener', 'sql', 'link', 'setup.sql');

var dbFile = process.argv[2] || DEFAULT_DB;
var db     = new DatabaseSync(dbFile);

db.exec(fs.readFileSync(SCHEMA, 'utf8'));
db.close();

console.log('schema applied to ' + dbFile);
