# link-shortener — Gina tutorial project

This is the completed source for the [Link Shortener tutorial](https://gina.io/docs/tutorials/link-shortener).

## Requirements

- Node.js 22.5+ (the SQLite connector uses the built-in `node:sqlite`)
- Gina CLI installed globally (`npm i -g gina`)

## Quick start

1. **Register the project with Gina**

   ```bash
   gina project:add @shortener
   ```

2. **Add the bundle**

   ```bash
   gina bundle:add api @shortener --import
   ```

3. **Create the database schema**

   ```bash
   node scripts/migrate.js
   ```

   The SQLite connector compiles its statements at boot, so the table must
   exist before the bundle starts. Safe to re-run — the statement is
   `CREATE TABLE IF NOT EXISTS`.

4. **Start the bundle**

   ```bash
   gina bundle:start api @shortener
   ```

   > Outside the project directory, always append `@projectname` to bundle commands.

5. **Open your browser**

   Check the startup output for the assigned port number (or run
   `gina port:list api @shortener`), then open:

   ```
   http://localhost:<port>
   ```

## Project layout

```
shortener/
├── manifest.json                           # project + bundle registry
├── package.json
├── env.json                                # per-environment hostnames
├── scripts/
│   └── migrate.js                          # pre-boot schema migration
└── src/
    └── api/
        ├── config/
        │   ├── connectors.json             # SQLite connector "shortener"
        │   └── routing.json                # 4 routes
        ├── controllers/
        │   └── controller.links.js         # GET /, POST /shorten, GET /:slug, GET /:slug/stats
        ├── models/
        │   └── shortener/
        │       ├── entities/link.js
        │       └── sql/link/
        │           ├── setup.sql
        │           ├── insert.sql
        │           ├── findBySlug.sql
        │           └── incrementHits.sql
        └── templates/html/links/
            ├── home.html                   # shorten form
            └── stats.html                  # hit-count stats page
```
