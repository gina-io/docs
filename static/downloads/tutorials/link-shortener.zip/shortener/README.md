# link-shortener — Gina tutorial project

This is the completed source for the [Link Shortener tutorial](https://gina.touman.dev/docs/tutorials/link-shortener).

## Requirements

- Node.js 18+
- Gina CLI installed globally (`npm i -g gina`)

## Quick start

1. **Register the project with Gina**

   ```bash
   gina project:add shortener /path/to/shortener
   ```

   Replace `/path/to/shortener` with the absolute path to this directory.

2. **Start the bundle**

   ```bash
   gina bundle:start api
   ```

3. **Open your browser**

   ```
   http://localhost:3080
   ```

## Project layout

```
shortener/
├── manifest.json                           # project + bundle registry
├── package.json
├── env.json                                # per-environment hostnames
└── src/
    └── api/
        ├── config/
        │   ├── connectors.json             # SQLite connector "shortener"
        │   └── routing.json               # 4 routes
        ├── controllers/
        │   └── controller.links.js        # GET /, POST /shorten, GET /:slug, GET /:slug/stats
        ├── models/
        │   └── shortener/
        │       ├── entities/link.js
        │       └── sql/link/
        │           ├── setup.sql
        │           ├── insert.sql
        │           ├── findBySlug.sql
        │           └── incrementHits.sql
        └── templates/html/content/links/
            ├── home.html                   # shorten form
            └── stats.html                  # hit-count stats page
```
