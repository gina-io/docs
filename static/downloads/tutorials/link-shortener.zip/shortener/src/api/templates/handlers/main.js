/**
 * Api Main handler
 */

// requires are put here
 
 var ApiHandler = ( function onApiMainHandled() {
     var self                = {}
     ;
 
     var init = function() {
 
         // Define global handlers/bindings here
         
         handle();
     }
 
 
     var handle = function () {
         console.debug('Main Api handler loaded !');         
     };
     
     init();
 })();