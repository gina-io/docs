/*
 * @param  {string} ?
 * @return {object}
 */
SELECT id, slug, url, hits, created FROM links WHERE slug = ?
