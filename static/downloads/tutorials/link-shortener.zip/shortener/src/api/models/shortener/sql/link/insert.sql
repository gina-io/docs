/*
 * @param {string} ?
 * @param {string} ?
 * @param {string} ?
 */
INSERT INTO links (slug, url, created) VALUES (?, ?, ?)
