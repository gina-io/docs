/*
 * @param {string} ?
 */
UPDATE links SET hits = hits + 1 WHERE slug = ?
