/**
 * Link entity.
 * SQL methods are loaded automatically from models/shortener/sql/link/.
 */
function LinkEntity() {
    var self = this;
}

module.exports = LinkEntity;
