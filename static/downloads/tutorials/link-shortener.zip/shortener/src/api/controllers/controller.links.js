var db    = getModel('shortener');
var CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

/**
 * Generates a random 6-character alphanumeric slug.
 * @returns {string}
 */
function generateSlug() {
    var slug = '';
    for (var i = 0; i < 6; i++) {
        slug += CHARS.charAt(Math.floor(Math.random() * CHARS.length));
    }
    return slug;
}

/**
 * LinksController — handles all URL shortener routes.
 */
function ApiLinksController() {
    var self = this;

    /**
     * GET / — render the shorten form.
     *
     * @param {object} req
     * @param {object} res
     */
    this.index = function(req, res) {
        self.render({});
    };

    /**
     * POST /shorten — create a new short link.
     * Expects { url } in the request body.
     * Returns { slug, short_url } as JSON.
     *
     * @param {object} req
     * @param {object} res
     */
    this.shorten = async function(req, res) {
        var url = (req.post && req.post.url) ? req.post.url.trim() : '';

        if (!url || !/^https?:\/\/.+/i.test(url)) {
            return self.renderJSON({
                status : 400,
                error  : 'A valid http:// or https:// URL is required.'
            });
        }

        // Generate a unique slug — retry on the rare collision.
        var slug     = generateSlug();
        var existing = await db.link.findBySlug(slug);
        while (existing) {
            slug     = generateSlug();
            existing = await db.link.findBySlug(slug);
        }

        await db.link.insert(slug, url, new Date().toISOString());

        var hostname = self.getConfig().hostname;

        self.renderJSON({
            slug      : slug
          , short_url : hostname + '/' + slug
        });
    };

    /**
     * GET /:slug — redirect to the original URL (302).
     * Increments the hit counter before redirecting.
     * Returns 404 JSON if the slug is unknown.
     *
     * @param {object} req
     * @param {object} res
     */
    this.follow = async function(req, res) {
        var slug = req.params.slug;
        var link = await db.link.findBySlug(slug);

        if (!link) {
            return self.renderJSON({
                status : 404,
                error  : 'Short link not found.'
            });
        }

        await db.link.incrementHits(slug);
        self.redirect(link.url);
    };

    /**
     * GET /:slug/stats — render the hit-counter page.
     * Returns 404 JSON if the slug is unknown.
     *
     * @param {object} req
     * @param {object} res
     */
    this.stats = async function(req, res) {
        var slug = req.params.slug;
        var link = await db.link.findBySlug(slug);

        if (!link) {
            return self.renderJSON({
                status : 404,
                error  : 'Short link not found.'
            });
        }

        self.render({ link: link });
    };
}

module.exports = ApiLinksController;
