# Notes API — Gina Tutorial

A simple in-memory REST API for creating and listing notes.
Built with [Gina](https://gina.io), the Node.js MVC framework.

## Prerequisites

- Node.js >= 22
- Gina installed globally (`npm install -g gina`)

## Setup

```bash
gina project:add @notes --path=$(pwd)
gina bundle:start api @notes
```

## Endpoints

| Method | URL             | Description       |
|--------|-----------------|-------------------|
| GET    | /api/notes      | List all notes    |
| POST   | /api/notes      | Create a note     |
| GET    | /api/notes/:id  | Get one note      |

## Test

```bash
curl http://localhost:3100/api/notes
curl -X POST http://localhost:3100/api/notes -H "Content-Type: application/json" -d '{"text": "Hello"}'
curl http://localhost:3100/api/notes/1
```

## Tutorial

Full walkthrough: https://gina.io/docs/tutorials/notes-api
