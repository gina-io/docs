// In-memory store — resets on bundle restart.
// Dev mode reloads the controller module on each request for hot-reloading;
// attaching the store to `global` keeps it alive across those reloads within
// the same bundle process.
if (!global.__notesStore) {
    global.__notesStore = { notes: [], nextId: 1 };
}
var store = global.__notesStore;

function ApiContentController() {
    var self = this;

    // GET /api/notes
    this.list = function(req, res) {
        self.renderJSON({ notes: store.notes, total: store.notes.length });
    };

    // POST /api/notes
    this.create = function(req, res) {
        var text = req.post.text;

        if (!text) {
            self.throwError(res, 400, '"text" is required');
            return;
        }

        var note = {
            id:        store.nextId++,
            text:      text,
            createdAt: new Date().toISOString()
        };
        store.notes.push(note);
        self.renderJSON({ note: note });
    };

    // GET /api/notes/:id
    this.getById = function(req, res) {
        var id   = Number(req.params.id);
        var note = store.notes.find(function(n) { return n.id === id; });

        if (!note) {
            self.throwError(res, 404, 'Note not found');
            return;
        }
        self.renderJSON({ note: note });
    };
}

module.exports = ApiContentController;
