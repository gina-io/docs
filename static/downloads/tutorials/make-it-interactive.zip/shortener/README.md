# link-shortener (interactive stage) — Gina tutorial project

This is the completed source for the [Make It Interactive tutorial](https://gina.io/docs/tutorials/make-it-interactive) —
the [Going to Production](https://gina.io/docs/tutorials/going-to-production) shortener made interactive:
a rule-bound shorten form, a project-defined `isUrl` validation rule, a live hit counter streamed
over server-sent events into an `<x-hits>` client component, and fragment navigation between pages.

It keeps everything the production stage established: user accounts (scrypt password hashing +
account lockout), per-user data isolation, deny-by-default route authorization, sessions,
HTTPS + HTTP/2, and structured JSON logs.

## Requirements

- Node.js 22.5+ (the SQLite connector and session store use the built-in `node:sqlite`)
- Gina 0.6.0+ installed globally (`npm i -g gina`)
- `openssl` on your PATH (self-signed certificate for local HTTPS)

## Quick start

1. **Register the project with Gina**

   ```bash
   gina project:add @shortener
   ```

2. **Add the bundle**

   ```bash
   gina bundle:add api @shortener --import
   ```

3. **Install the project dependency** (sessions)

   ```bash
   npm install
   ```

4. **Create the database schema**

   ```bash
   node scripts/migrate.js
   ```

   Safe to re-run. If you kept the database from the Link Shortener tutorial,
   this upgrades it in place (adds the `links.user_id` column).

5. **Create a local TLS certificate** — the bundle ships with HTTPS + HTTP/2
   enabled (`src/api/config/settings.json > server`), so it will refuse to
   start without credentials:

   ```bash
   mkdir -p ~/.gina/certificates/scopes/local/localhost
   cd ~/.gina/certificates/scopes/local/localhost
   openssl req -x509 -newkey rsa:2048 -nodes -sha256 -subj "/CN=localhost" \
     -keyout private.key -out certificate.crt
   cp certificate.crt ca_bundle.crt
   ```

6. **Start the bundle**

   ```bash
   SESSION_SECRET=$(node -e "console.log(require('crypto').randomBytes(64).toString('hex'))") \
   gina bundle:start api @shortener
   ```

7. **Open your browser**

   Check the assigned HTTPS port (`gina port:list api @shortener` — the
   `http/2.0 → https` line), then open:

   ```
   https://localhost:<port>/signup
   ```

   Your browser will warn about the self-signed certificate — accept it for
   localhost. Create an account and start shortening.

## Project layout

```
shortener/
├── manifest.json                           # project + bundle registry
├── package.json                            # express-session dependency
├── env.json                                # per-environment hostnames
├── scripts/
│   └── migrate.js                          # pre-boot schema migration + upgrade
└── src/
    └── api/
        ├── config/
        │   ├── connectors.json             # "shortener" ORM + "session" store
        │   ├── routing.json                # 10 routes (2 negotiable; public: signup, login, /:slug)
        │   └── settings.json               # auth (deny-by-default) + server (HTTP/2)
        ├── index.js                        # session middleware wiring
        ├── forms/
        │   ├── rules/shorten.json          # isRequired + the custom isUrl rule
        │   └── validators/isUrl/main.js    # project-defined rule (BROWSER ONLY)
        ├── locales/en.json                 # _validator.isUrl message
        ├── public/js/components/x-hits.js  # <x-hits> live counter
        ├── controllers/
        │   ├── controller.auth.js          # signup, login (lockout), logout
        │   └── controller.links.js         # dashboard, shorten, follow, stats, events (SSE)
        ├── models/shortener/
        │   ├── entities/{link,user}.js
        │   └── sql/{link,user}/*.sql       # per-user queries
        └── templates/html/
            ├── auth/{login,signup}.html
            ├── includes/x-hits.html
            ├── layouts/main.html            # <main data-gina-nav>
            └── links/{home,stats}.html
```
