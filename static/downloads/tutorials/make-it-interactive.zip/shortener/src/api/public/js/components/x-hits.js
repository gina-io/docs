/**
 * <x-hits> — a live hit counter.
 *
 * Behaviour-only class for the server-rendered markup in
 * templates/html/includes/x-hits.html. The count that matters for SEO and for
 * a reader with JavaScript disabled is already in the HTML the server sent;
 * this class only keeps it current.
 *
 * The lifecycle IS the connection's lifecycle: the stream opens in
 * connectedCallback and closes in disconnectedCallback. There is deliberately
 * no `_bound`-style guard on the open — a component that is removed and
 * re-inserted (a fragment swap, a reopened popin) must open a fresh stream,
 * and that pair of callbacks is the only place that can be known.
 */
(function () {
    'use strict';

    class XHits extends HTMLElement {

        connectedCallback() {
            var config = {};

            try {
                config = JSON.parse(this.getAttribute('data-x-hits') || '{}');
            } catch (err) {
                config = {};
            }

            this._count  = this.querySelector('[data-role="count"]');
            this._status = this.querySelector('[data-role="status"]');

            if (!config.url) {
                return;
            }

            var self = this;

            this._source = new EventSource(config.url);

            this._source.addEventListener('open', function () {
                self._setStatus('live');
            });

            this._source.addEventListener('message', function (event) {
                var payload;

                try {
                    payload = JSON.parse(event.data);
                } catch (err) {
                    return;
                }

                if (payload && typeof payload.hits !== 'undefined') {
                    // textContent, never innerHTML — the value is data, not markup.
                    self._count.textContent = String(payload.hits);
                    self.dispatchEvent(new CustomEvent('x-hits:changed', {
                        detail   : { hits: payload.hits },
                        bubbles  : true,
                        composed : true
                    }));
                }
            });

            this._source.addEventListener('error', function () {
                // EventSource reconnects on its own; say so rather than looking broken.
                self._setStatus('reconnecting…');
            });
        }

        disconnectedCallback() {
            // An orphaned EventSource reconnects forever. The stream never
            // outlives the markup it feeds.
            if (this._source) {
                this._source.close();
                this._source = null;
            }

            this._setStatus('');
        }

        _setStatus(text) {
            if (!this._status) {
                return;
            }

            this._status.textContent = text;
            this._status.hidden      = (text === '');
        }
    }

    customElements.define('x-hits', XHits);
}());
