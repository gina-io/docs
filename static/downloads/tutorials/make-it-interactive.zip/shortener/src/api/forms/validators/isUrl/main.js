/**
 * isUrl — the value must be an absolute http:// or https:// URL.
 *
 * Gina ships no URL rule, so this is a project-defined one. The file is a bare
 * function expression: Gina reads it from disk when the bundle starts and
 * registers it as a chainable rule named after this directory — `isUrl`.
 *
 * Inside, `self`, `local` and `replace` are the validation engine, handed to
 * every custom validator. `this` is the field being checked.
 *
 * Browser only. The server never runs this file, which is why POST /shorten
 * re-checks the URL itself. That re-check is the real gate; this is feedback.
 */
function () {
    var errors  = self[this.name]['errors'] || {};
    var value   = this.value;
    var isValid = true;

    // An empty value is isRequired's business. Bypass it, or a required field
    // left blank reports two messages for one mistake. Strictly '' — a JSON
    // body's 0 or false must not coerce their way into this bypass.
    if (value !== '') {
        // Type-guard before the regex: a JSON body can put a number, a boolean
        // or an array on this field, and a throw here would abort the whole
        // validation pass, not just this rule.
        isValid = typeof value === 'string' && /^https?:\/\/[^\s]+$/i.test(value);
    }

    if (!isValid) {
        // local.errorLabels is the message catalog. Read it — never hardcode a
        // literal here: Gina seeds this key with its default only when the app
        // has NOT supplied one, so a `_validator.isUrl` catalog entry (or a
        // gina.validator.setErrorLabels({isUrl}) key) must be allowed to win.
        errors['isUrl'] = replace(this['error'] || local.errorLabels['isUrl'], this, 'isUrl');
    } else {
        delete errors['isUrl'];
    }

    // Keep .valid consistent with an isRequired error that is still standing.
    this.valid = isValid && !errors['isRequired'];

    if (errors.count() > 0) {
        this['errors'] = errors;
    }

    return self[this['name']];
}
