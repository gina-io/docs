/**
 * One-off schema migration — run before starting the bundle.
 *
 * Applies both setup.sql files (links + users), then upgrades a database
 * created by the Link Shortener tutorial: the links table gains a user_id
 * column so every short link can belong to an account. Safe to re-run —
 * the statements are CREATE TABLE IF NOT EXISTS and the ALTER only runs
 * when the column is missing.
 *
 * Usage:
 *   node scripts/migrate.js                  # default database location
 *   node scripts/migrate.js /path/to/db.sqlite
 */
var fs           = require('fs');
var os           = require('os');
var path         = require('path');
var DatabaseSync = require('node:sqlite').DatabaseSync;

// Matches the connector's default: <gina home>/<database>.sqlite
var DEFAULT_DB  = path.join(os.homedir(), '.gina', 'shortener.sqlite');
var SQL_DIR     = path.join(__dirname, '..', 'src', 'api', 'models', 'shortener', 'sql');
var LINK_SCHEMA = path.join(SQL_DIR, 'link', 'setup.sql');
var USER_SCHEMA = path.join(SQL_DIR, 'user', 'setup.sql');

var dbFile = process.argv[2] || DEFAULT_DB;
var db     = new DatabaseSync(dbFile);

db.exec(fs.readFileSync(LINK_SCHEMA, 'utf8'));
db.exec(fs.readFileSync(USER_SCHEMA, 'utf8'));

// Upgrade path: a links table created by the intermediate tutorial has no
// user_id column, and CREATE TABLE IF NOT EXISTS will not add one.
var columns   = db.prepare("SELECT name FROM pragma_table_info('links')").all();
var hasUserId = false;
for (var i = 0; i < columns.length; i++) {
    if (columns[i].name === 'user_id') { hasUserId = true; break; }
}
if (!hasUserId) {
    db.exec('ALTER TABLE links ADD COLUMN user_id INTEGER');
    console.log('upgraded: links.user_id column added');
}

db.close();

console.log('schema applied to ' + dbFile);
