/*
 * @param {string} ?
 * @param {string} ?
 * @param {string} ?
 */
INSERT INTO users (email, password_hash, created) VALUES (?, ?, ?)
