CREATE TABLE IF NOT EXISTS links (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    slug    TEXT    NOT NULL UNIQUE,
    url     TEXT    NOT NULL,
    hits    INTEGER NOT NULL DEFAULT 0,
    created TEXT    NOT NULL,
    user_id INTEGER
)
