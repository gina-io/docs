/*
 * @param  {string} ?
 * @return {object}
 */
SELECT id, email, password_hash AS passwordHash, created FROM users WHERE email = ?
