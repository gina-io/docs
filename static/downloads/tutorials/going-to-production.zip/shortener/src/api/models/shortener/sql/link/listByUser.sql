/*
 * @param  {number} ?
 * @return {array}
 */
SELECT id, slug, url, hits, created FROM links WHERE user_id = ? ORDER BY id DESC
