/*
 * @param {string} ?
 * @param {number} ?
 */
UPDATE users SET password_hash = ? WHERE id = ?
