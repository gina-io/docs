/**
 * User entity.
 * SQL methods are loaded automatically from models/shortener/sql/user/.
 */
function UserEntity() {
    var self = this;
}

module.exports = UserEntity;
