/*
 * @param  {string} ?
 * @param  {number} ?
 * @return {object}
 */
SELECT id, slug, url, hits, created FROM links WHERE slug = ? AND user_id = ?
