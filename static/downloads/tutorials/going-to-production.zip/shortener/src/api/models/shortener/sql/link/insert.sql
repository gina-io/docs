/*
 * @param {string} ?
 * @param {string} ?
 * @param {string} ?
 * @param {number} ?
 */
INSERT INTO links (slug, url, created, user_id) VALUES (?, ?, ?, ?)
