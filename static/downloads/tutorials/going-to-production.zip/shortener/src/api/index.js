/**
 * Api bundle
 *
 * */
var api          = require('gina');
var lib          = api.lib;
// The Session plugin wraps express-session, injecting the hardened cookie
// defaults (sameSite: "lax", httpOnly: true, secure: "auto") before
// express-session sees them — cookie values you set here always win.
// See: https://gina.io/docs/guides/sessions
var session      = api.plugins.Session(require('express-session'));
var SessionStore = lib.SessionStore;

api.onInitialize(function(event, app) {
    // Resolves the "session" entry in connectors.json → the SqliteStore class.
    // The entry MUST be named "session" — the factory reads the name off
    // express-session's own function name, which cannot be changed.
    var SqliteStore = new SessionStore(session);

    app.use(session({
        secret           : process.env.SESSION_SECRET || 'dev-only-change-me'
      , resave           : false
      , saveUninitialized: false
      , store            : new SqliteStore()
      , rolling          : true                   // idle window refreshes on activity
      , cookie           : { maxAge: 86400000 }   // 1 day idle cap
      , absoluteTimeout  : 28800000               // 8 h hard cap since login
    }));

    // then notify the server that the startup sequence can be resumed
    event.emit('complete', app); // this is important !
});

// Catch unhandled errors
api.onError(function(err, req, res, next){
    console.error('[ BOOTSTRAP ] <api> fatal error: ' + err.message + '\nstack:\n'+ err.stack);
    next(err);
});

api.start();
