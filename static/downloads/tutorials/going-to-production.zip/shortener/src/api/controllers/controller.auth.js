var authn = require('gina').lib.authn;
var db    = getModel('shortener');

// Dev-mode hot-reload re-requires controller modules, so plain module-level
// state resets between requests (and each reload would mint a new lockout
// engine, leaking its sweep timer). Anchor process-wide state on `global`:
// it survives reloads, and still resets on a real restart.
if (!global.__shortenerAuth) {
    global.__shortenerAuth = {
        // The credential-stuffing brake. Defaults are PCI-DSS §8.3.4: lock
        // after 10 failures, for 30 minutes. The key is user-supplied (an
        // email), so it MUST be normalised — without this, Ada@x.com and
        // ada@x.com are two separate counters and an attacker gets the full
        // threshold once per spelling.
        lockout: authn.createLockout({
            normalizeKey: function(key) { return String(key || '').trim().toLowerCase(); }
        })
        // dummyVerify's cost reference — minted once, just below.
      , referenceHash: null
    };
    // Every hash this app stores is minted at current defaults, so the
    // unknown-account branch always costs the same as a real verify — a
    // login that answers faster for unknown emails than known ones is a
    // user-enumeration oracle.
    authn.hashPassword('reference-cost-probe', function(err, hash) {
        if (!err) { global.__shortenerAuth.referenceHash = hash; }
    });
}
var lockout = global.__shortenerAuth.lockout;

// ?error=<code> → human message rendered by the form pages
var LOGIN_ERRORS = {
    invalid : 'Invalid email or password.'
  , locked  : 'Too many failed attempts. Try again in 30 minutes.'
};
var SIGNUP_ERRORS = {
    email  : 'A valid email address is required.'
  , policy : 'Password rejected: use at least 12 characters, and avoid your email address.'
  , exists : 'An account with this email already exists.'
};

/**
 * AuthController — sign-up, login and logout.
 */
function ApiAuthController() {
    var self = this;

    /**
     * GET /signup — render the sign-up form.
     *
     * @param {object} req
     * @param {object} res
     */
    this.signupPage = function(req, res) {
        var code = (req.get && req.get.error) ? req.get.error : null;
        self.render({ error: SIGNUP_ERRORS[code] || null });
    };

    /**
     * GET /login — render the login form.
     *
     * @param {object} req
     * @param {object} res
     */
    this.loginPage = function(req, res) {
        var code = (req.get && req.get.error) ? req.get.error : null;
        self.render({ error: LOGIN_ERRORS[code] || null });
    };

    /**
     * POST /signup — create the account, then sign the visitor straight in.
     * Expects { email, password } from the form body.
     *
     * @param {object} req
     * @param {object} res
     */
    this.signup = async function(req, res) {
        var email    = (req.post && req.post.email)    ? String(req.post.email).trim().toLowerCase() : '';
        var password = (req.post && req.post.password) ? String(req.post.password) : '';

        if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
            return self.redirect('/signup?error=email');
        }

        // Policy first — synchronous, and cheap compared to the hash.
        var check = authn.validatePasswordPolicy(password, { deny: [ email ] });
        if (!check.valid) {
            return self.redirect('/signup?error=policy');
        }

        var existing = await db.user.findByEmail(email);
        if (existing) {
            return self.redirect('/signup?error=exists');
        }

        authn.hashPassword(password, async function(err, hash) {
            if (err) {
                // Under load the hashing queue sheds with AUTHN_QUEUE_FULL —
                // a 503, not a 500: the caller should retry, nothing is broken.
                return self.throwError(res, (err.code === 'AUTHN_QUEUE_FULL') ? 503 : 500, err);
            }
            // The router's async safety net only covers the action's own
            // promise — inside a callback, guard the awaits yourself.
            try {
                await db.user.insert(email, hash, new Date().toISOString());
                var user = await db.user.findByEmail(email);

                // req.login() rotates the session, destroying everything in the
                // pre-login record — including the gate's haltedRequest snapshot.
                // Read it before the call, re-set it inside the callback.
                var halted = (req.session && req.session.haltedRequest) ? req.session.haltedRequest : null;

                req.login({ id: user.id, email: user.email }, function(loginErr) {
                    if (loginErr) { return self.throwError(res, 500, loginErr); }
                    if (halted) {
                        req.session.haltedRequest = halted;
                        return self.resumeRequest();
                    }
                    self.redirect('/');
                });
            } catch (dbErr) {
                self.throwError(res, 500, dbErr);
            }
        });
    };

    /**
     * POST /login — verify credentials, then bind the session.
     * The lockout check comes BEFORE any key derivation: a hash costs
     * ~100 ms of memory-hard work, and letting a locked account reach it
     * would turn the login route into an amplifier.
     *
     * @param {object} req
     * @param {object} res
     */
    this.login = function(req, res) {
        var email    = (req.post && req.post.email)    ? String(req.post.email).trim().toLowerCase() : '';
        var password = (req.post && req.post.password) ? String(req.post.password) : '';

        lockout.check(email, async function(err, state) {
            if (err) { return self.throwError(res, 500, err); }
            if (state.locked) {
                return self.redirect('/login?error=locked');
            }

            try {
                var user = await db.user.findByEmail(email);

                // Unknown account — spend the same work, then deny identically.
                if (!user) {
                    return authn.dummyVerify(password, { like: global.__shortenerAuth.referenceHash }, function(dummyErr) {
                        if (dummyErr) { return self.throwError(res, 503, dummyErr); }
                        self.redirect('/login?error=invalid');
                    });
                }

                authn.verifyPassword(password, user.passwordHash, function(verifyErr, ok) {
                    if (verifyErr) {
                        return self.throwError(res, (verifyErr.code === 'AUTHN_QUEUE_FULL') ? 503 : 500, verifyErr);
                    }
                    if (!ok) {
                        return lockout.recordFailure(email, function() {
                            self.redirect('/login?error=invalid');
                        });
                    }

                    lockout.recordSuccess(email, function() {
                        // The one moment the plaintext is in hand — upgrade a
                        // stale hash minted under older parameters.
                        if (authn.needsRehash(user.passwordHash)) {
                            authn.hashPassword(password, function(rehashErr, fresh) {
                                if (!rehashErr) {
                                    db.user.updatePasswordHash(fresh, user.id)
                                        .catch(function(e) { console.warn('rehash failed: ' + e.message); });
                                }
                            });
                        }

                        // req.login() rotates the session id BEFORE binding the
                        // user — the session-fixation defense. Rotation destroys
                        // the pre-login record, INCLUDING the authorization
                        // gate's haltedRequest snapshot — so read the snapshot
                        // first and re-set it inside the callback.
                        var halted = (req.session && req.session.haltedRequest) ? req.session.haltedRequest : null;

                        req.login({ id: user.id, email: user.email }, function(loginErr) {
                            if (loginErr) { return self.throwError(res, 500, loginErr); }

                            // Replay where the visitor was heading, or fall back
                            // to the dashboard.
                            if (halted) {
                                req.session.haltedRequest = halted;
                                return self.resumeRequest();
                            }
                            self.redirect('/');
                        });
                    });
                });
            } catch (dbErr) {
                self.throwError(res, 500, dbErr);
            }
        });
    };

    /**
     * POST /logout — clear the session user AND destroy the stored record.
     *
     * @param {object} req
     * @param {object} res
     */
    this.logout = function(req, res) {
        req.logout(function(err) {
            if (err) { return self.throwError(res, 500, err); }
            self.redirect('/login');
        });
    };
}

module.exports = ApiAuthController;
