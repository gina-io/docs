var db    = getModel('shortener');
var CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

// Six-character route paths live in the same /:slug space as short links —
// never mint a slug that an exact route would shadow.
var RESERVED = ['signup', 'logout'];

/**
 * Generates a random 6-character alphanumeric slug.
 * @returns {string}
 */
function generateSlug() {
    var slug = '';
    for (var i = 0; i < 6; i++) {
        slug += CHARS.charAt(Math.floor(Math.random() * CHARS.length));
    }
    return slug;
}

/**
 * LinksController — handles all URL shortener routes.
 */
function ApiLinksController() {
    var self = this;

    /**
     * GET / — the dashboard: shorten form + the signed-in user's links.
     * Gated by auth.requireAuthByDefault, so req.session.user is always
     * set by the time this action runs.
     *
     * @param {object} req
     * @param {object} res
     */
    this.index = async function(req, res) {
        var links = await db.link.listByUser(req.session.user.id);
        self.render({ links: links, email: req.session.user.email });
    };

    /**
     * POST /shorten — create a new short link owned by the signed-in user.
     * Expects { url } in the request body.
     * Returns { slug, short_url } as JSON.
     *
     * @param {object} req
     * @param {object} res
     */
    this.shorten = async function(req, res) {
        var url = (req.post && req.post.url) ? req.post.url.trim() : '';

        if (!url || !/^https?:\/\/.+/i.test(url)) {
            return self.renderJSON({
                status : 400,
                error  : 'A valid http:// or https:// URL is required.'
            });
        }

        // Generate a unique slug — retry on the rare collision, and never
        // mint one of the reserved route words.
        var slug     = generateSlug();
        var existing = await db.link.findBySlug(slug);
        while (existing || RESERVED.indexOf(slug) > -1) {
            slug     = generateSlug();
            existing = await db.link.findBySlug(slug);
        }

        await db.link.insert(slug, url, new Date().toISOString(), req.session.user.id);

        var hostname = self.getConfig().hostname;

        self.renderJSON({
            slug      : slug
          , short_url : hostname + '/' + slug
        });
    };

    /**
     * GET /:slug — redirect to the original URL (302). PUBLIC: a short
     * link must work for everyone, signed in or not.
     * Increments the hit counter before redirecting.
     * Returns 404 JSON if the slug is unknown.
     *
     * @param {object} req
     * @param {object} res
     */
    this.follow = async function(req, res) {
        var slug = req.params.slug;
        var link = await db.link.findBySlug(slug);

        if (!link) {
            return self.renderJSON({
                status : 404,
                error  : 'Short link not found.'
            });
        }

        await db.link.incrementHits(slug);
        self.redirect(link.url);
    };

    /**
     * GET /:slug/stats — the hit-counter page, owner-only.
     * A slug owned by someone else answers the same 404 as a missing one —
     * a 403 would confirm to a stranger that the slug exists.
     *
     * @param {object} req
     * @param {object} res
     */
    this.stats = async function(req, res) {
        var slug = req.params.slug;
        var link = await db.link.findBySlugForUser(slug, req.session.user.id);

        if (!link) {
            return self.renderJSON({
                status : 404,
                error  : 'Short link not found.'
            });
        }

        self.render({ link: link });
    };
}

module.exports = ApiLinksController;
